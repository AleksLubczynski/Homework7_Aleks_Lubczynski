//
//  Homework7_Aleks_LubczynskiTests.swift
//  Homework7_Aleks_LubczynskiTests
//
//  Created by Aleks Lubczynski on 9/30/25.
//

import Testing
@testable import Homework7_Aleks_Lubczynski

struct Homework7_Aleks_LubczynskiTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
